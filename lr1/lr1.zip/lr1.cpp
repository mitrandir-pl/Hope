﻿#include <iostream>
#include <vector>
#include "game.h"
#include "cell.h"
#include <Windows.h>
#include <string>
#include <cstdlib>
#include <conio.h>


int main()
{
	Game newGame;
	newGame.start_game();
}